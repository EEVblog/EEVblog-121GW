using MvvmCross.Platform.Plugins;

namespace MvxPluginNugetTest.Android.Bootstrap
{
    public class BlePluginBootstrap
        : MvxPluginBootstrapAction<MvvmCross.Plugins.BLE.PluginLoader>
    {
    }
}