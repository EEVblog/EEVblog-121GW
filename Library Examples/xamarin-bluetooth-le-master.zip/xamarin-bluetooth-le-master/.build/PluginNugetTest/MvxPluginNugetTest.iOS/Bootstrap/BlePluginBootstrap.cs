using MvvmCross.Platform.Plugins;

namespace MvxPluginNugetTest.iOS.Bootstrap
{
    public class BlePluginBootstrap
        : MvxLoaderPluginBootstrapAction<MvvmCross.Plugins.BLE.PluginLoader, MvvmCross.Plugins.BLE.iOS.Plugin>
    {
    }
}