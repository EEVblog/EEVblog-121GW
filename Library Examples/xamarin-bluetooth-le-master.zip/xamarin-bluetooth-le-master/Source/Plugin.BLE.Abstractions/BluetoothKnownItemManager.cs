﻿namespace Plugin.BLE.Abstractions
{
	public class BluetoothKnownItemManager
	{
	}
}