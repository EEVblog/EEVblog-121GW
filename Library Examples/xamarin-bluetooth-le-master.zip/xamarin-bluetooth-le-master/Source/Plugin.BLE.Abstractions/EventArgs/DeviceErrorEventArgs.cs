namespace Plugin.BLE.Abstractions.EventArgs
{
    public class DeviceErrorEventArgs : DeviceEventArgs
    { 
        public string ErrorMessage;
    }
}