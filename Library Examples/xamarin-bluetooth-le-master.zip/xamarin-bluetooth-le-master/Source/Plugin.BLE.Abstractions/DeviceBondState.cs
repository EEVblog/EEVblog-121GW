namespace Plugin.BLE.Abstractions
{
    public enum DeviceBondState
    {
        NotBonded,
        Bonding,
        Bonded
    }
}