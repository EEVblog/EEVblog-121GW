﻿using Xamarin.Forms;

namespace BLE.Client.Pages
{
    public partial class CharacteristicDetailPage
    {
        public CharacteristicDetailPage()
        {
            InitializeComponent();
        }
    }
}
