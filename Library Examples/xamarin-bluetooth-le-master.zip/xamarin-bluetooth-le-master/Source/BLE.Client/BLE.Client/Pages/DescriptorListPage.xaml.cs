﻿namespace BLE.Client.Pages
{
    public partial class DescriptorListPage 
    {
        public DescriptorListPage()
        {
            InitializeComponent();
        }
    }
}
