﻿namespace BLE.Client.Pages
{
    public partial class DeviceListPage
    {
        public DeviceListPage()
        {
            InitializeComponent();
        }
    }
}
