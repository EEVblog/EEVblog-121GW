﻿using Xamarin.Forms;

namespace BLE.Client.Pages
{
    public partial class ServiceListPage
    {
        public ServiceListPage()
        {
            InitializeComponent();
        }
    }
}
