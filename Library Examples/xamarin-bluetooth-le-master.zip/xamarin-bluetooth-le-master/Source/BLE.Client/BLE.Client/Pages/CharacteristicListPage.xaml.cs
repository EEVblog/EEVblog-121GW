﻿using Xamarin.Forms;

namespace BLE.Client.Pages
{
    public partial class CharacteristicListPage
    {
        public CharacteristicListPage()
        {
            InitializeComponent();
        }
    }
}
