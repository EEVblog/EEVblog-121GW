﻿using MvvmCross.Platform.Plugins;

namespace BLE.Client.iOS.Bootstrap
{
    public class BlePluginBootstrap
         : MvxLoaderPluginBootstrapAction<MvvmCross.Plugins.BLE.PluginLoader, MvvmCross.Plugins.BLE.iOS.Plugin>
    {
    }
}