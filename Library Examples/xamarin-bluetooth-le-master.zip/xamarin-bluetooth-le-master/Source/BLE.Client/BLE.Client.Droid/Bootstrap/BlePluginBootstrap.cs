﻿using MvvmCross.Platform.Plugins;

namespace BLE.Client.Droid.Bootstrap
{
    public class BlePluginBootstrap
        : MvxPluginBootstrapAction<MvvmCross.Plugins.BLE.PluginLoader>
    {
    }
}