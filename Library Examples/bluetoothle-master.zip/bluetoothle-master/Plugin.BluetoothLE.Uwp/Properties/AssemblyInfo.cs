﻿using System.Reflection;

[assembly: AssemblyTitle("Acr.Ble.Uwp")]
[assembly: AssemblyDescription("")]