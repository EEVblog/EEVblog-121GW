﻿using System;


namespace Plugin.BluetoothLE
{
    public enum PairingStatus
    {
        Unavailiable,
        NotPaired,
        Paired
    }
}
