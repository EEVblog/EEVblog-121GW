﻿using System;


namespace Plugin.BluetoothLE
{
    public enum BleScanType
    {
        Background,
        LowPowered,
        Balanced,
        LowLatency
    }
}
