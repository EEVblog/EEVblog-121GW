﻿using System;


namespace Plugin.BluetoothLE
{
    public enum DescriptorEvent
    {
        Read,
        Write
    }
}
