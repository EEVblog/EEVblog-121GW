﻿using System.Reflection;

[assembly: AssemblyTitle("Plugin.BluetoothLE.Abstractions")]
[assembly: AssemblyDescription("")]
