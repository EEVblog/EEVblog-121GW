﻿using System;


namespace Plugin.BluetoothLE
{
    public enum ConnectionPriority
    {
        Low,
        Normal,
        High
    }
}
