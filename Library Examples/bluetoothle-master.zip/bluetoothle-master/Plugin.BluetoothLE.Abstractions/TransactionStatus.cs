﻿using System;


namespace Plugin.BluetoothLE
{
    public enum TransactionStatus
    {
        Active,
        Committing,
        Committed,
        Aborted
    }
}
