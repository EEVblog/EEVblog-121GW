﻿using System;


namespace Plugin.BluetoothLE
{
    public enum CharacteristicEvent
    {
        Read,
        Write,
        Notification
    }
}
