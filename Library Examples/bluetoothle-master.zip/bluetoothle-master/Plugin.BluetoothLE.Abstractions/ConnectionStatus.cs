﻿using System;


namespace Plugin.BluetoothLE
{
    public enum ConnectionStatus
    {
        Disconnected,
        Disconnecting,
        Connected,
        Connecting
    }
}
