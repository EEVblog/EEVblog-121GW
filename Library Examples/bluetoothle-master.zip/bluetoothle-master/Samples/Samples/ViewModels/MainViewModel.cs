﻿using System;

namespace Samples.ViewModels
{
    public class MainViewModel : AbstractViewModel
    {
    }
}
