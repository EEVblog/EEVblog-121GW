﻿using System;


namespace Samples.ViewModels.TestCases
{
    public class LogItem
    {
        public string Text { get; set; }
        public string Detail { get; set; }
    }
}
