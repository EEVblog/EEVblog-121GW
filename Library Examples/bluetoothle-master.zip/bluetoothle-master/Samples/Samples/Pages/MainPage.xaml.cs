﻿using System;
using Xamarin.Forms;


namespace Samples.Pages
{
    public partial class MainPage : TabbedPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
