﻿using System;
using System.ComponentModel;


namespace Samples.Services
{
    public interface IAppSettings : INotifyPropertyChanged
    {
        bool EnableBackgroundScan { get; set; }
        Guid BackgroundScanServiceUuid { get; set; }
        //Guid BgScanToConnect

        //bool AreNotificationsEnabled { get; set; }
        bool IsLoggingEnabled { get; set; }
    }
}
