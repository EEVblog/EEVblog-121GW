﻿using System.Reflection;

[assembly: AssemblyTitle("Plugin.BluetoothLE")]
[assembly: AssemblyDescription("")]
