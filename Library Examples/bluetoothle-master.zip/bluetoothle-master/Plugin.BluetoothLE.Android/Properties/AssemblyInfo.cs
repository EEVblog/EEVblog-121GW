﻿using System.Reflection;

[assembly: AssemblyTitle("Plugin.BluetoothLE.Android")]
[assembly: AssemblyDescription("")]
