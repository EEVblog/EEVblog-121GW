﻿using System.Reflection;

[assembly: AssemblyTitle("Plugin.BluetoothLE.tvOS")]
[assembly: AssemblyDescription("")]
