﻿using System.Reflection;

[assembly: AssemblyTitle("Plugin.BluetoothLE.MonoBlueZ")]
[assembly: AssemblyDescription("")]
