﻿using System.Reflection;

[assembly: AssemblyTitle("Plugin.BluetoothLE.iOS")]
[assembly: AssemblyDescription("")]
