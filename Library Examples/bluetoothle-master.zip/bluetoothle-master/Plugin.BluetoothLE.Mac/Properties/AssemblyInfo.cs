﻿using System.Reflection;

[assembly: AssemblyTitle ("Plugin.BluetoothLE.Mac")]
[assembly: AssemblyDescription ("")]